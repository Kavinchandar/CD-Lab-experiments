The code is written in <b>Python3</b> <br>

On Linux, to run the code, use the following command in the terminal.
```
$ python3 nfa2dfa.py
```
This code assumes that the States are represented by numeric values (e.g.: 1,2,3,...) and the Alpahbets are Symbols (e.g.: a,b,c,...). The States will be generated automatically.
