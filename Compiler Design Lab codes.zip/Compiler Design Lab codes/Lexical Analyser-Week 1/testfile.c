#include <stdio.h> // This is a header file
int main()
{
    int x, y, v1, 2v;
    a = 10;
    printf("The value of a is %d ", a);
    return 0;
}
